﻿var XLSX = require('../');
var testCommon = require('./Common.js');

var file = 'formula_stress_test.xlsx';

describe(file, function () {
	// Opening the file currently crashes node
	//testCommon(file);
});